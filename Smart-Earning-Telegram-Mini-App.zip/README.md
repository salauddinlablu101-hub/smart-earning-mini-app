# Smart Earning Telegram Mini App

This package contains a Telegram Bot + Mini App + Admin Panel.

## Added from the reference picture

- Yellow Notification popup shown when the Mini App opens.
- Bengali welcome/payment message.
- Two Telegram Join buttons.
- `OK, Understood` button.
- Mobile responsive design.
- Popup is remembered for the current session.

## IMPORTANT: set your two Telegram links

Open `public/app.js` and change:

```js
const GROUP_1_URL = "https://t.me/your_group";
const GROUP_2_URL = "https://t.me/your_channel";
```

to your real group/channel links.

## Deploy

GitHub stores the code, but it does not run this Node.js app by itself.

Recommended simple setup:
1. Upload all files to a GitHub repository.
2. Create a Web Service on Render from that repository.
3. Build command: `npm install`
4. Start command: `npm start`
5. Add environment variables:
   - `BOT_TOKEN` = BotFather token
   - `BOT_USERNAME` = bot username without @
   - `APP_URL` = your Render HTTPS URL
   - `ADMIN_PASSWORD` = your admin password
6. In @BotFather set the Mini App / Web App URL to your Render URL.

## Admin

Open `/admin` on your deployed URL and use `ADMIN_PASSWORD`.

## Warning

The task claim endpoint is still an MVP and can be claimed repeatedly. Do not use real-money payouts until task-claim tracking, anti-fraud and rate limits are added.
